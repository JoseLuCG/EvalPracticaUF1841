const numbers = [0,1,2];
let sum = 0;//Declarar las constantes antes del bucle.
for (let item of numbers) {
    sum += item;
}

console.log(sum)