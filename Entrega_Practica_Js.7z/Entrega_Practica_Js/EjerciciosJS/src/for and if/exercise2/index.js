const numbers = [0,1,2,4,5,9,3,6,7,8];
// Put your code here
let counter = 0;
for (let item of numbers) {
    // Put your code here
    counter ++;
}

console.log(counter)