// Simple
console.log("Simple")
for (let idx = 0; idx < 10 ; idx++) {
    console.log(idx);
}

// Menos simple
console.log("Not so simple")
let start = 5;
let end = 12;
let step = 2;
for (let idx = start; idx < end; idx+=step) {
    console.log(idx);
}