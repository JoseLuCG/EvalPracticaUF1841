const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

// Put your code here
for ( let idx=3; idx<=5 ; idx++){
    console.log(numbers[idx]);
}
