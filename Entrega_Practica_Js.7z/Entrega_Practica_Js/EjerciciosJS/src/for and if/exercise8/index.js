// Put your code here
for (multiplying = 0; multiplying <= 10; multiplying++){
    for (multiplier = 0; multiplier <= 10; multiplier++){
        console.log(`${multiplying} x ${multiplier} = ${multiplier*multiplying}`);
    }
}