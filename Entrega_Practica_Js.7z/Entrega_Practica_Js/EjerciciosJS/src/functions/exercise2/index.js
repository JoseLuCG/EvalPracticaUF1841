number = 0;

function plusone(number) {
    number = number + 1;
    return number;
}

plusone(number);

console.log(number)