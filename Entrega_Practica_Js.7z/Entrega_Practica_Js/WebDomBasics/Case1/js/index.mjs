import { data } from "./models/main.mjs";
import {dataToHTMLList} from "./controllers/main.mjs";
//console.log(data);
dataToHTMLList(data);
//console.log(data);

