import { useState } from "react";
import './styles/App.css';

function App() {
  const [counter, setCounter] = useState(0);

  function addCounter() {
    setCounter(counter+1);
  }
  return (
    <>
    <h1>
      Has pulsado el boton {counter} veces.
    </h1>
    <div className="container">
    <button onClick={addCounter}>Pulsar</button>
    </div>
    </>
  );
}

export default App;
