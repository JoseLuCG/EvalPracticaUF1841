# **Final Proyect**

## **Description:**

The proyect will be based in develop a social aplication that allows users increment your social circle and start a friendship with new people that have common interests or they are close each other.

