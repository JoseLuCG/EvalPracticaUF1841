import './Message.css';

function Message () {
    return (
        <>
        <p>This is the component message</p>
        <p className='message'>This is a message</p>
        </>
    );
}
export default Message;