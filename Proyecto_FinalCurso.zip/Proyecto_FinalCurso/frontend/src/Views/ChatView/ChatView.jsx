import './ChatView.css';

function ChatView () {
    return(
        <div className='chatContainer'>
            <h2>This is the chat view</h2>
        </div>
    );
}
export default ChatView;